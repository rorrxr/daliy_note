document.write("자바스크립트를 학습하자");
